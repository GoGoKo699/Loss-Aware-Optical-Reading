# Single-photon four-path fault reading: checkpoint 06

A fixed four-mode interferometer identifies which path acquired a pi phase flip.
Known unequal path losses are compensated by preparing input probability
proportional to inverse transmission. One photon and four output click detectors
suffice for the ideal quantum receiver.

The mechanism is inherited from phase-oracle and Hadamard optical reading.
The research candidate is an exact loss-dependent comparison with all classical
coherent-state mixtures at the same mean signal-photon budget, including a
regime where the classical strategy wins. Novelty has not been cleared.

## Read

- `REPORT.md`: scientific result and hardware scope.
- `proofs/PROOFS.md`: exact model, analytic bounds, attainability, bright-pulse
  accounting, and finite-error ceiling.
- `SOURCE_AUDIT.md`: direct prior art and unresolved novelty questions.
- `results/candidate_recipe.json`: example input amplitudes and fixed decoder.

## Reproduce

Python 3.10+ with NumPy and SciPy is expected; the archived run used Python 3.13.5,
NumPy 2.3.5, and SciPy 1.17.0. Create an environment appropriate for your system,
install `requirements.txt`, then run from this directory:

```bash
python src/validate.py
```

The command regenerates the files in `results/`. It performs no network calls
and needs no GPU. Most checks are small matrix operations; the search diagnostics
use SciPy differential evolution and HiGHS linear programming. Universal claims
are supported by analytic proofs, not by finite numerical optimization.

`requirements-recorded.txt` records the versions used here; it is not a complete
OS/container lock. Reruns may have different runtimes, version metadata, and
small optimizer variations. No SDP solver or interval-arithmetic certificate
was used. Reproduction has not been tested in the user's local Ubuntu environment.

## Scope

Exactly one of four tested paths has a pi flip, with a uniform prior. There is
no fifth healthy label. The quantum input is one photon occupying only those
four paths. A known diagonal loss channel precedes an ideal receiver. Empty
outputs count as inconclusive. No occupied bypass rail, quantum idler, or repeated
unknown-device call is included in the quantum optimality theorem.

The classical comparison permits arbitrarily bright rare pulses under a mean
signal budget, free coherent phase references, and arbitrary quantum measurements.
It is a bound on classical *probe states*. It is not restricted to direct
intensity measurement or phase-randomized laser light.

This is a research checkpoint, not a lab-ready proposal or hardware specification.
All numerical transmission and phase-noise values are illustrative. Existing
multiphoton/chirality checkpoints are outside this branch and were not modified.

No third-party paper, figure, or code has been redistributed. No public reuse
license has been chosen for this working package.
