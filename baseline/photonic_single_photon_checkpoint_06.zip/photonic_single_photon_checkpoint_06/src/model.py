"""Four-path, single-use phase-fault reading. All probabilities are unconditional.

No-error discrimination may return an inconclusive outcome. One unknown pi phase
flip is promised, with a uniform prior. Loss is diagonal before a lossless reader.
"""
from __future__ import annotations
import numpy as np
from numpy.typing import ArrayLike, NDArray
from scipy.optimize import brentq

F64 = NDArray[np.float64]
C128 = NDArray[np.complex128]
D = np.ones((4, 4), dtype=float) / 2 - np.eye(4)
CODE = 2 * D
NC = 1.5 * np.log(3.0)

def _vec4(x: ArrayLike, name: str) -> F64:
    a = np.asarray(x, dtype=float)
    if a.shape != (4,) or not np.all(np.isfinite(a)):
        raise ValueError(f'{name} must be a finite vector of length four')
    return a

def photon_design(eta: ArrayLike) -> tuple[F64, float]:
    e = _vec4(eta, 'eta')
    if np.any((e <= 0) | (e > 1)):
        raise ValueError('Each transmission must lie in (0, 1]')
    inv = 1 / e
    p = inv / inv.sum()
    return np.sqrt(p), float(4 / inv.sum())

def photon_outputs(eta: ArrayLike, amplitudes: ArrayLike | None = None) -> C128:
    e = _vec4(eta, 'eta')
    if np.any((e < 0) | (e > 1)):
        raise ValueError('Each transmission must lie in [0, 1]')
    a = photon_design(e)[0] if amplitudes is None else np.asarray(amplitudes, complex)
    if a.shape != (4,) or not np.isclose(np.vdot(a, a).real, 1, atol=1e-10):
        raise ValueError('Amplitudes must be normalized and length four')
    return np.diag(np.sqrt(e) * a) @ CODE

def photon_fixed_probe_usd(eta: ArrayLike, p: ArrayLike) -> float:
    e, p = _vec4(eta,'eta'), _vec4(p,'p')
    if np.any(e < 0) or np.any(p < 0) or not np.isclose(p.sum(), 1):
        raise ValueError('Invalid loss or input probabilities')
    return float(4 * np.min(e * p))

def coherent_gram(q: ArrayLike) -> F64:
    q = _vec4(q,'q')
    if np.any(q < 0):
        raise ValueError('Output energies cannot be negative')
    a = np.exp(-2 * q)
    return np.diag(1 - a * a) + np.outer(a, a)

def coherent_usd_formula(q: ArrayLike) -> tuple[float, F64]:
    """Exact equal-prior USD optimum for one fixed coherent illumination.

The Gram matrix is diagonal plus a positive rank-one term. Returns the
unconditional mean conclusive rate and per-hypothesis failure probabilities.
"""
    q = _vec4(q,'q')
    if np.any(q < 0):
        raise ValueError('Output energies cannot be negative')
    a = np.exp(-2 * q)
    m = int(np.argmax(a))
    delta = max(2 * a[m] - a.sum(), 0.0)
    f = a * a + delta * a
    f[m] = a[m] * a[m] - delta * a[m]
    return float(1 - f.mean()), f

def coherent_usd_certificate(q: ArrayLike) -> tuple[F64, C128]:
    """Primal conclusive probabilities and an equal-value PSD dual (trace form)."""
    q = _vec4(q,'q'); a = np.exp(-2*q)
    _, f = coherent_usd_formula(q)
    m = int(np.argmax(a)); delta = 2*a[m]-a.sum()
    if delta > 1e-13:
        z = -np.ones(4, dtype=complex); z[m] = 1
    else:
        # Construct a closed quadrilateral with side lengths a_i.
        # Pair the two largest and the two smallest sides for conditioning.
        order = np.argsort(-a)
        b = a[order]
        lo=max(abs(b[0]-b[1]),abs(b[2]-b[3]))
        hi=min(b[0]+b[1],b[2]+b[3])
        L=(lo+hi)/2
        if L < 1e-14:
            z = np.array([1,-1,1,-1], dtype=complex)
        else:
            def ang(u: float,v: float) -> float:
                return float(np.arccos(np.clip((L*L+u*u-v*v)/(2*L*u),-1,1)))
            zz=np.array([np.exp(1j*ang(b[0],b[1])),
                         np.exp(-1j*ang(b[1],b[0])),
                         -np.exp(1j*ang(b[2],b[3])),
                         -np.exp(-1j*ang(b[3],b[2]))])
            z=np.empty(4,complex);z[order]=zz
    # diag dual is the uniform prior 1/4.
    return 1-f, np.outer(z,z.conj())/4

def waterfill(eta: ArrayLike, budget: float = 1.0) -> tuple[F64, float, float]:
    """Optimize the achievable displacement-and-click receiver.

For eta=t*(1,1,1,r), t*budget<=1, the proof establishes this as the
optimum over all classical positive-P transmitters at a mean-energy budget.
For general losses this function is only an achievable classical rate.
"""
    e = _vec4(eta,'eta')
    if budget < 0 or np.any((e < 0)|(e > 1)):
        raise ValueError('Invalid budget or transmission')
    if budget == 0 or e.max()==0:
        return np.zeros(4),0.0,float(e.max())
    pos=e>0
    def allocation(loglam: float) -> F64:
        n=np.zeros(4)
        n[pos]=np.maximum((np.log(e[pos])-loglam)/(4*e[pos]),0)
        return n
    upper=float(np.log(e.max())); lower=upper-4*e.max()*budget-10
    while allocation(lower).sum() < budget: lower -= 10
    root=brentq(lambda x: allocation(x).sum()-budget,lower,upper,xtol=1e-14)
    n=allocation(root)
    score=float(np.mean(-np.expm1(-4*e*n)))
    return n,score,float(np.exp(root))

def balanced_family(x: float, r: float) -> tuple[float,float]:
    """B_r(x), its slope. Effective lossless-arm energy x, loss ratio r."""
    if x < 0 or not 0 <= r <=1: raise ValueError('Invalid x or r')
    if r==0 or r <= np.exp(-4*x/3):
        lam=float(np.exp(-4*x/3))
        return .75*(1-lam),lam
    lam=float(np.exp((np.log(r)-4*r*x)/(1+3*r)))
    return 1-(3+1/r)*lam/4,lam

def pure_classical_family(x: float, r: float) -> float:
    b,_=balanced_family(x,r)
    if x < NC: return b
    a=float(np.exp(-2*x/3)); erased=1-1.5*a+1.5*a*a
    return max(b,erased)

def ratio_threshold(t: float) -> float:
    if not 0 < t <=1: raise ValueError('t must be in (0,1]')
    b=.75*(-np.expm1(-4*t/3))
    return float(b/(4*t-3*b))

def classical_error_bound(t: float, error: float, mean_energy: float=1) -> float:
    """Universal correct-conclusive bound; may be loose for unequal losses.

Classical means a nonnegative mixture of coherent probes. All signals cross
at most once; total signal energy is charged. t upper-bounds each path loss.
"""
    if not (0<=t<=1 and 0<=error<=1 and mean_energy>=0):
        raise ValueError('Invalid bound inputs')
    a=-np.expm1(-t*mean_energy)
    return float(min(1-error,(np.sqrt(a)+np.sqrt(error/3))**2))

def receiver_decomposition() -> list[tuple[str,list[list[float]]]]:
    h=np.array([[1,1],[1,-1]],float)/np.sqrt(2)
    w=np.kron(h,h)
    z=np.diag([1,-1,-1,-1])
    return [('H_tensor_H',w.tolist()),('phase_0_pi_pi_pi',z.tolist()),('H_tensor_H',w.tolist())]
