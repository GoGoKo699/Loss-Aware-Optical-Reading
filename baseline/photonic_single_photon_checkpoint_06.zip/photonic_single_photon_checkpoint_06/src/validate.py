"""Reproduce independent checks, candidate design, and comparison tables.

Run: python src/validate.py
Requires NumPy and SciPy only. Numerical optimizers are diagnostics; the bounds
are proved in proofs/PROOFS.md. No external data or online calls are used.
"""
from __future__ import annotations
import csv, hashlib, json, platform, sys, time
from pathlib import Path
import numpy as np
import scipy
from scipy.optimize import differential_evolution, linprog
from scipy.linalg import eigh
from scipy.special import factorial
from model import (D, CODE, NC, photon_design, photon_outputs,
    coherent_gram, coherent_usd_formula, coherent_usd_certificate,
    waterfill, balanced_family, pure_classical_family, ratio_threshold,
    classical_error_bound, receiver_decomposition)

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'results'; OUT.mkdir(exist_ok=True)
SEED=26091406
rng=np.random.default_rng(SEED)
checks=[]

def check(name: str, error: float, tolerance: float=1e-10) -> None:
    value=float(error)
    checks.append({'name':name,'residual':value,'tolerance':tolerance,
                   'passed':bool(np.isfinite(value) and value<=tolerance)})
    if not checks[-1]['passed']:
        raise AssertionError(checks[-1])

def write_csv(name: str, rows: list[dict]) -> None:
    with (OUT/name).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def simplex(z: np.ndarray) -> np.ndarray:
    return np.array([z[0],(1-z[0])*z[1],(1-z[0])*(1-z[1])*z[2],
                     (1-z[0])*(1-z[1])*(1-z[2])])

start=time.perf_counter()
check('four_path_decoder_unitary',np.linalg.norm(D.T@D-np.eye(4)))
check('code_decoder',np.linalg.norm(D@CODE-2*np.eye(4)))
ops=receiver_decomposition();dec=np.eye(4)
for _,op in ops: dec=np.asarray(op)@dec
check('balanced_coupler_decomposition',np.linalg.norm(dec-D))

# The harmonic-mean law: exact target, optimality Gram condition, and a separate
# eight-mode unitary that includes all four loss environments.
for z in range(120):
    eta=rng.uniform(.03,1,4)
    amp,h=photon_design(eta); psi=photon_outputs(eta)
    check(f'balanced_target_{z}',np.linalg.norm(D@psi-np.sqrt(h)*np.eye(4)))
    check(f'probe_normalization_{z}',abs(amp@amp-1))
    l=np.sqrt(eta);k=np.sqrt(1-eta)
    loss=np.block([[np.diag(l),-np.diag(k)],[np.diag(k),np.diag(l)]])
    check(f'loss_unitary_{z}',np.linalg.norm(loss.T@loss-np.eye(8)))
    read=np.block([[D,np.zeros((4,4))],[np.zeros((4,4)),np.eye(4)]])
    initial=np.vstack([np.diag(amp)@CODE,np.zeros((4,4))])
    full=read@loss@initial
    check(f'full_space_target_{z}',np.linalg.norm(full[:4]-np.sqrt(h)*np.eye(4)))
    check(f'full_space_loss_{z}',np.max(np.abs(np.sum(abs(full[4:])**2,axis=0)-(1-h))))
    # For a different arbitrary input, the feasible equal-success USD matrix
    # attains the diagonal upper bound 4 min(eta*p).
    p=rng.dirichlet(np.ones(4));q=eta*p;s=4*q.min()
    gram=CODE.T@np.diag(q)@CODE
    check(f'fixed_probe_usd_psd_{z}',max(0,-np.linalg.eigvalsh(gram-s*np.eye(4)).min()))
    check(f'fixed_probe_harmonic_upper_{z}',max(0,s-h))

# Fixed-coherent-probe analytic optimum, with independent primal and dual PSD
# certificates, including the high-energy branch and almost singular examples.
coh_cases=[np.zeros(4),np.array([0,2,2,2]),np.array([0,10,10,10]),
           np.array([0,0,1,1])]
coh_cases += [rng.dirichlet(np.ones(4))*rng.uniform(0,12) for _ in range(220)]
for z,q in enumerate(coh_cases):
    gram=coherent_gram(q);score,fail=coherent_usd_formula(q)
    suc,dual=coherent_usd_certificate(q)
    check(f'coherent_primal_psd_{z}',max(0,-np.linalg.eigvalsh(gram-np.diag(suc)).min()),1e-9)
    check(f'coherent_primal_nonnegative_{z}',max(0,-suc.min()),1e-9)
    check(f'coherent_dual_psd_{z}',max(0,-np.linalg.eigvalsh(dual).min()),1e-9)
    check(f'coherent_dual_diagonal_{z}',np.max(abs(np.diag(dual)-.25)),1e-9)
    check(f'coherent_primal_dual_gap_{z}',abs(np.trace(gram@dual).real-score),1e-8)

# Independent photon-number series for the coherent Gram matrix. The four
# multimode output amplitudes have equal total energy. Their inner products
# factor into a Poisson series of photon-sector overlaps.
for z in range(30):
    q=rng.uniform(0,.45,4);amps=np.diag(np.sqrt(q))@CODE
    N=q.sum();inner=amps.T@amps
    series=sum(inner**n/factorial(n) for n in range(41))*np.exp(-N)
    check(f'coherent_fock_series_{z}',np.max(abs(series-coherent_gram(q))),1e-10)

# Pure-state energy optimization checks. The exact theorem reduces the optimum
# to max(water filling, high-energy background-certification branch).
optimization=[]
for r in [0,.05,.2,.5,1]:
    for x in [.1,1,1.7,2.5,5]:
        eta=np.array([1,1,1,r])
        def objective(z):return -coherent_usd_formula(eta*x*simplex(z))[0]
        ans=differential_evolution(objective,[(0,1)]*3,seed=SEED+len(optimization),
             popsize=10,maxiter=350,tol=1e-10,polish=True)
        predicted=pure_classical_family(x,r)
        numerical=-float(ans.fun)
        # Check no numerical counterexample. A local miss is not a failed proof.
        check(f'pure_energy_no_counterexample_{r}_{x}',max(0,numerical-predicted),2e-7)
        check(f'pure_energy_optimization_gap_{r}_{x}',abs(numerical-predicted),2e-7)
        optimization.append({'r':r,'effective_energy':x,'formula':predicted,
              'search_value':numerical,'formula_minus_search':predicted-numerical,
              'optimizer_success':bool(ans.success),'evaluations':ans.nfev})
write_csv('pure_coherent_energy_search.csv',optimization)

# Arbitrarily bright, randomized pulses cannot beat the low-mean budget bound:
# independent random pure probes and exact one-dimensional formula evaluated
# against the global supporting line. A finite-grid LP checks flash mixtures.
flash=[]
for r in [0,.01,.2,.4,.8,1]:
    for mean in [.05,.3,.7,1]:
        value,slope=balanced_family(mean,r)
        xs=np.r_[np.linspace(0,4,401),np.geomspace(4.01,100,100),mean]
        vals=np.array([pure_classical_family(float(x),r) for x in xs])
        line=value+slope*(xs-mean)
        check(f'global_support_{r}_{mean}',max(0,float(np.max(vals-line))),2e-12)
        for z in range(12):
            x=float(rng.uniform(0,30));q=np.array([1,1,1,r])*x*rng.dirichlet(np.ones(4))
            check(f'general_probe_support_{r}_{mean}_{z}',
                  max(0,coherent_usd_formula(q)[0]-(value+slope*(x-mean))),2e-12)
        ans=linprog(-vals,A_ub=xs[None,:],b_ub=[mean],A_eq=np.ones((1,len(xs))),
                      b_eq=[1],bounds=(0,None),method='highs')
        if not ans.success: raise RuntimeError(ans.message)
        opt=-float(ans.fun)
        check(f'flash_mixture_lp_{r}_{mean}',abs(opt-value),1e-8)
        flash.append({'r':r,'mean_effective_energy':mean,'analytic':value,
                      'grid_mixture_lp':opt,'grid_max_energy':100,
                      'support_atoms_over_1e-7':int(np.count_nonzero(ans.x>1e-7))})
write_csv('flash_mixture_checks.csv',flash)

# Error-margin inequality, independently checked against random five-outcome
# POVMs on the support of each coherent ensemble. This checks the algebra,
# not the existence of a saturating receiver.
for z in range(120):
    t=float(rng.uniform(.05,1));n=rng.dirichlet(np.ones(4))
    eta=rng.uniform(0,t,4);q=eta*n;G=coherent_gram(q)
    eig,V=eigh(G);states=(V*np.sqrt(np.maximum(eig,0)))@V.conj().T
    raw=[]
    for _ in range(5):
        A=rng.normal(size=(4,4))+1j*rng.normal(size=(4,4));raw.append(A@A.conj().T)
    S=sum(raw);w,U=eigh(S);inv=(U*(w**-.5))@U.conj().T
    povm=[inv@e@inv for e in raw]
    probs=np.array([[np.vdot(states[:,j],E@states[:,j]).real for j in range(4)]for E in povm])
    C=float(sum(probs[j,j] for j in range(4))/4)
    E=float((probs[:4].sum()-4*C)/4)
    check(f'error_margin_bound_{z}',max(0,C-classical_error_bound(t,E)),1e-10)

# Nontrivial low-error tests: in the symmetric coherent case the ceiling has
# a constructive saturating POVM up to the minimum-error endpoint. This tests
# the small-error regime, where random generic POVMs are not informative.
for t in np.linspace(.05,1,12):
    overlap=np.exp(-t)
    emax=3/16*(np.sqrt(1+3*overlap)-np.sqrt(1-overlap))**2
    G=coherent_gram(np.full(4,t/4))
    vals,vecs=eigh(G)
    root=(vecs*np.sqrt(vals))@vecs.T
    invroot=(vecs*(vals**-.5))@vecs.T
    for fraction in np.linspace(0,1,9):
        error=float(fraction*emax)
        correct=float((np.sqrt(1-overlap)+np.sqrt(error/3))**2)
        B=np.full((4,4),np.sqrt(error/3));np.fill_diagonal(B,np.sqrt(correct))
        M=B@invroot
        residual=np.eye(4)-M.T@M
        check(f'low_error_povm_psd_{t}_{fraction}',
              max(0,-np.linalg.eigvalsh(residual).min()),1e-10)
        check(f'low_error_povm_amplitudes_{t}_{fraction}',
              np.linalg.norm(M@root-B),1e-10)
        check(f'low_error_bound_saturation_{t}_{fraction}',
              abs(correct-classical_error_bound(float(t),error)),1e-10)

# Boundary and allocation tables.
rows=[]
for t,r in [(1,1),(.7,1),(.7,.8),(.7,.5),(.7,.2),(1,.2),(.3,.8),(.3,.5)]:
    eta=np.array([t,t,t,t*r]);amp,H=photon_design(eta)
    n,C,lam=waterfill(eta)
    b,_=balanced_family(t,r)
    check(f'waterfill_closed_form_{t}_{r}',abs(C-b))
    rows.append({'t':t,'r':r,'quantum_conclusive':H,'classical_optimum':C,
        'quantum_minus_classical':H-C,'quantum_p_bad':float(amp[3]**2),
        'coherent_n_bad':float(n[3]),'crossover_r':ratio_threshold(t)})
write_csv('main_comparison.csv',rows)
thresholds=[]
for t in [.05,.1,.2,.3,.5,.7,.9,1]:
    r=ratio_threshold(t)
    Q=t*4*r/(1+3*r);C,_=balanced_family(t,r)
    check(f'crossover_equality_{t}',abs(Q-C))
    check(f'crossover_inactive_region_{t}',max(0,r-np.exp(-4*t/3)))
    for rr in np.linspace(.001,1,200):
        q=t*4*rr/(1+3*rr);c,_=balanced_family(t,float(rr))
        check(f'crossover_sign_{t}_{rr:.6f}',max(0,-(rr-r)*(q-c)),1e-12)
    thresholds.append({'t':t,'critical_r':r,'classical_abandons_bad_below':float(np.exp(-4*t/3))})
write_csv('crossover.csv',thresholds)

# Explicit optical matrices for eta=(.7,.7,.7,.56); the phase fault is separately
# chosen and kept hidden from the preparation and receiver controllers.
eta=np.array([.7,.7,.7,.56]);amp,H=photon_design(eta)
np.savez(OUT/'candidate_matrices.npz',eta=eta,input_amplitudes=amp,receiver=D,
         oracle_code_columns=CODE,surviving_outputs=photon_outputs(eta))
(OUT/'candidate_recipe.json').write_text(json.dumps({
    'port_order':['0','1','2','3'],'transmissions':eta.tolist(),
    'input_amplitudes':amp.tolist(),'input_probabilities':(amp**2).tolist(),
    'receiver_matrix':D.tolist(),'receiver_factorization':receiver_decomposition(),
    'conclusive_rate':H,'inconclusive_rate':1-H,
    'phase_patterns':[([(-1 if i==j else 1) for i in range(4)])for j in range(4)],
    'oracle_settings_not_given_to_reader':True,
    'requires_separate_preparation_oracle_receiver_sections':True,
    'all_rates_include_empty_outputs':True},indent=2)+'\n')

# Independent Gaussian phase-noise integration with product factorization.
# All path phases have independent zero-mean Gaussian errors sigma, common
# distribution across hypotheses. This is an illustrative model, not lab data.
phase=[]
nodes,weights=np.polynomial.hermite.hermgauss(28);weights=weights/np.sqrt(np.pi)
for sigma in [0,.03,.05,.1,.2,.3]:
    coh=np.sum(weights*np.exp(1j*np.sqrt(2)*sigma*nodes))
    cond=.25+.75*abs(coh)**2
    integrated=H*cond
    correct=H*(.25+.75*np.exp(-sigma*sigma))
    error=H*.75*(-np.expm1(-sigma*sigma))
    check(f'gaussian_phase_quadrature_{sigma}',abs(integrated-correct))
    bound=classical_error_bound(.7,error)
    phase.append({'sigma_rad':sigma,'quantum_correct':correct,'quantum_wrong':error,
       'quantum_inconclusive':1-H,'classical_correct_upper_same_error':bound,
       'certified_margin':correct-bound})
write_csv('phase_error_screen.csv',phase)

summary={'status':'PASS','seed':SEED,'checks':len(checks),
         'max_residual':max(c['residual'] for c in checks),
         'max_algebraic_residual':max(c['residual'] for c in checks if 'optimization_gap' not in c['name']),
         'max_pure_energy_search_gap':max(abs(v['formula_minus_search']) for v in optimization),
         'runtime_seconds':time.perf_counter()-start,
         'numpy':np.__version__,'scipy':scipy.__version__,'python':sys.version,
         'platform':platform.platform(),
         'statement':'Floating-point consistency tests. Proofs, not finite tests, justify universal claims.',
         'cvxpy_available':False,'sdp_solver_claimed':False}
(OUT/'validation.json').write_text(json.dumps({'summary':summary,'checks':checks},indent=2)+'\n')
print(json.dumps(summary,indent=2))
print('\nMain table:')
for row in rows: print(row)
print('\nPhase screen:')
for row in phase:print(row)
