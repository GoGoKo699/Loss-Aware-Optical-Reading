# Apply the completed local study to the existing branch

The study is scientifically completed locally but not remotely committed. The
connection exposed read-only tools during this continuation; direct Git access
failed at DNS resolution. Do not treat the existing work-order commit as if it
contains the new results.

Target repository: GoGoKo699/Loss-Aware-Optical-Reading.
Target branch: research/robustness-01.
Expected starting commit: ddb17c5040e17cb0078121081afe15de70158fe8.
Main baseline: de73c9b094036b756d1ff008eaccbc52cec46207.

After verifying that the target branch has not advanced and the checkout is clean:

```bash
git switch research/robustness-01
git rev-parse HEAD
git status --short
git apply --check /path/to/robustness-01.patch
git apply /path/to/robustness-01.patch
python studies/robustness-01/test_local.py
```

Run the documented reproduction and optimizer-free witness checks, inspect the
additions, and commit only studies/robustness-01/. Do not reset an advanced branch,
modify WORK_ORDER.md, overwrite another workspace, or merge into main as part of
this application. A later integration requires separate review. Actual remote CI
must be inspected at the resulting commit; none was run for this local packet.

The patch adds only new paths under the permitted study directory. It contains
no changes to proofs, numerical source, existing tests, templates, acquisition
protocol, original archives, or prior evidence. Its round-trip was tested in an
empty disposable Git worktree with byte comparisons. That test does not claim
an authenticated full-repository checkout or inherited regression run.
