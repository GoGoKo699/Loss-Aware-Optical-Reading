# Suggested attribution update, not applied to main

This note is an integration recommendation. The root claim ledger, source audit,
contribution note, and first-experiment documents have not been edited.

| Existing unit | Recommended classification | Reason |
|---|---|---|
| S18 full-text gap | Resolved for the theorem/appendix scope comparison of arXiv:2603.19911v1 | Formal objective, finite-n result, input class, and relevant appendices inspected; not a direct substitution for A or B. |
| S20 original-source gap | Resolved through author-uploaded full article text; PDF-format limitation retained | Theorem 1 and proof now read directly rather than only quoted by another article. |
| B's zero-error statistical bound | Established S20 specialization | Uniform-prior C<=1-R. |
| B's F=0 statistical bound | Established S22 normalization | X=(m-1)R/m, P_d=C. |
| B's finite-failure statistical bound | Straightforward failure-row completion of S22's published proof algebra | Explicit derivation in REDUCTIONS.md, without assuming an arbitrary POVM is optimal. |
| Full passive-map, all-intensity classical ceiling | Derived optical source-class corollary; useful benchmark; precise publication priority unestablished | Coherent overlaps, spectral norm, Jensen, and Cauchy-Schwarz extend the credited bound. Do not call it a new general discrimination inequality. |
| A's joint input-only optimum | Candidate model-specific contribution, status otherwise unchanged | No exact subsumption in this follow-up; not global priority clearance. |
| M1/P1/P2 physical and statistical requirements | Unchanged | Attribution does not alter the theorem, source class, calibration, penalties, or acquisition contract. |

## Suggested short contribution wording

We solve a specified joint preparation-and-measurement problem for a lossy
orthogonal phase code: input retuning reaches the ideal reliability tradeoff with
a fixed decoder. To assess the resulting reader, we derive a classical
illumination benchmark from established state-discrimination relations, explicitly
retaining arbitrary receivers, phase references, and all finite-mean intensity
mixtures. The benchmark is used with the stated calibration and trial-accounting
requirements; it is not presented as a newly discovered universal discrimination
principle.

This wording does not assert that A is priority-cleared or that a laboratory
advantage has been observed. A reader should be able to identify the known
inequalities and the specific new argument being evaluated.

## Integration safeguards

Apply any later canonical wording edits through the repository's authorized
old/new document-hash chain, not by refreshing original evidence hashes. Keep the
older novelty audit unchanged as a historical record. The most direct safe
import of this packet adds only `audits/novelty-02/`; it does not itself modify
protected documents or need a scientific repair.
