# Focused source follow-up

**Read [REPORT.md](REPORT.md) for the decision and [REDUCTIONS.md](REDUCTIONS.md)
for the exact argument.** The named S18/S20 source gaps are addressed. The new
Bagan-et-al. predecessor supplies an exact no-failure match and a straightforward
route to the full statistical inequality. The all-classical optical certificate
remains valid, with narrower novelty framing.

This packet is local, not committed. GitHub write actions were unavailable and
direct Git DNS failed. Target baseline:
`db17e1ec1868107b0fe1042d5a480769b552633e`.
No canonical code, proof, protocol, previous evidence, or source archive changed.

- [Sources and access limits](SOURCES.md)
- [Suggested claim update, not applied](PROPOSED_CLAIM_UPDATE.md)
- [Scoped work order](WORK_ORDER.md)
- [Starting state](START.json)
- [Execution summary](SUMMARY.json)
- [Source/search record](SEARCH_LOG.json)

## Reproduce the focused checks

In the intended repository, from its root:

```bash
python -m pip install -r requirements-recorded.txt
python audits/novelty-02/check_equivalences.py --output results/runs/novelty-02-check
```

Or run `check_equivalences.py --output /path/to/a/new/directory` from this packet
with Python and NumPy installed. Existing directories and frozen repository
result locations are rejected. The script has no network calls and imports
neither canonical scientific code nor code from the cited articles.

The stored [RESULTS.json](results/RESULTS.json) has 717 assertions with individual
residuals/tolerances. [ENVIRONMENT.json](results/ENVIRONMENT.json) records the
actual local runtime. The second run reproduced the result bytes. These are
finite consistency tests; the universal reduction is the written argument,
not an extrapolation from the tests.

## Import status

The companion additions-only patch can be checked with `git apply --check` in a
suitable checkout. Inspect the current branch/baseline and stop if the target
audit directory already exists. Create a new bounded branch rather than reset
an existing branch. Importing the packet does not approve a protected-document
rewrite, claim priority, trigger an experiment, or certify a later CI run.

No third-party article files are included. Follow the primary-source links.
