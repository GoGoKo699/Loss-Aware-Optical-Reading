# Exact reductions and the remaining optical step

This is a comparison with the pinned project's Theorem 3, not a change to its
mathematics. Source identifiers refer to [SOURCES.md](SOURCES.md). All rates
below are unconditional. No source has been declared new merely because a
complete identical formula was not found.

## 1. Notation and the zero-error predecessor

There are m hypotheses, normalized pure states |psi_j>, and priors pi_j. Define

$$
W=\sum_{j\ne k}\sqrt{\pi_j\pi_k}\,|\langle\psi_j|\psi_k\rangle|.
$$

The ordered sum counts each unordered pair twice. S20, Theorem 1, gives the
unambiguous correct-answer upper bound

$$
C_{E=0}\le 1-\frac{W}{m-1}.
$$

For uniform priors define the average root overlap

$$
R=\frac{1}{m(m-1)}\sum_{j\ne k}|\langle\psi_j|\psi_k\rangle|.
$$

Then W=(m-1)R, and S20 becomes C<=1-R. The paper's Hilbert space can be finite:
a finite coherent alphabet lies in a span of dimension at most m even though the
ambient Fock space is infinite. S20 does not by itself state an energy-constrained
transmitter theorem or a finite-error bound. Its discussion of successive
measurements concerns processing the supplied state, not free additional copies
or new queries of the hidden device.

## 2. Exact no-failure match to Bagan and colleagues

S22 defines X as the l1 coherence divided by m. For a pure path prior whose
amplitudes are sqrt(pi_j), its weighted Gram form is X=W/m. Lemma 1, Eq. (9),
states the minimum-error relation

$$
X\le\frac{m-2}{m}(1-P_d)
+\frac{2}{m}\sqrt{(m-1)P_d(1-P_d)}.
$$

At uniform priors, X=(m-1)R/m. Setting F=0, C=P_d and E=1-P_d yields exactly

$$
R\le\frac{m-2}{m-1}E+2\sqrt{\frac{CE}{m-1}}.
$$

Thus the no-inconclusive part of the project's measurement inequality is a known
relation, not a newly discovered multiclass discrimination bound.

**Important logical point:** the printed lemma uses the optimal P_d. We do not
replace it silently with an arbitrary receiver's C. The next section reuses its
published matrix proof (Eqs. (27)-(36)); that algebra needs neither optimality
nor unit total weight for the conclusive part. This also handles deliberately
poor label assignments and singular ensembles.

## 3. Add a failure outcome without changing the number of hypotheses

Let p(y|j) be the probabilities for any actual measurement and fixed decoder.
Group its records into conclusive labels y=1,...,m and one failure label ?. Define

$$
b_{yj}=\sqrt{\pi_jp(y|j)}.
$$

Let B be the m by m conclusive block and b_? the failure row. Put

$$
C=\sum_y b_{yy}^2,\qquad
E=\sum_{y=1}^m\sum_{j\ne y}b_{yj}^2,\qquad
F=\sum_j b_{?j}^2.
$$

Measurement cannot reduce root fidelity, so

$$
W\le\sum_{j\ne k}\sum_y b_{yj}b_{yk}.
$$

For a conclusive row y let d_y=b_yy^2 and w_y=sum_(j!=y)b_yj^2. The row's ordered
pair sum satisfies

$$
\sum_{j\ne k}b_{yj}b_{yk}
\le 2\sqrt{(m-1)d_yw_y}+(m-2)w_y.
$$

Indeed, separate the terms containing the correct entry and use
(sum_(j!=y)b_yj)^2 <= (m-1)w_y. Sum over y and use Cauchy-Schwarz on
sum_y sqrt(d_y w_y). This is the same off-diagonal counting and square-root
estimate used in S22's proof. It gives

$$
\sum_{j\ne k}(B^TB)_{jk}
\le 2\sqrt{(m-1)CE}+(m-2)E.
$$

The failure row contributes at most

$$
\sum_{j\ne k}b_{?j}b_{?k}
=\left(\sum_j b_{?j}\right)^2-F\le(m-1)F.
$$

Consequently

$$
W\le (m-1)F+2\sqrt{(m-1)CE}+(m-2)E.
$$

Divide by m-1 at uniform priors:

$$
\boxed{R\le F+2\sqrt{CE/(m-1)}+\frac{m-2}{m-1}E.}
$$

This is the exact statistical inequality in the current project proof. Failure
is an additional *outcome*, not a fifth hypothesis. The proof does not impose
label-independent failure, equal per-label success, or a projective receiver.
It also does not substitute the conditional accuracy C/(1-F) for C.

**Attribution conclusion:** this is a straightforward failure-row completion of
established discrimination algebra. This audit is not claiming that S22 prints
the optical formula or the F>0 formula verbatim. Nor is the completion being
promoted as a new independent theorem.

### An explicit saturation check

For nonnegative C,E,F with sum one, construct m normalized vectors as columns of
sqrt(m) times an (m+1) by m matrix. Its conclusive block has diagonal sqrt(C/m)
and off-diagonal sqrt(E/[m(m-1)]); its failure row is constant sqrt(F/m).
Measurement in the row basis gives the declared C,E,F. Their pairwise overlap is

$$
c=F+2\sqrt{CE/(m-1)}+\frac{m-2}{m-1}E.
$$

It saturates the completed inequality. For m=4, C=.5, E=.03, F=.47, c is
0.6314213562373095. This is an independently constructed consistency witness,
not a new optical experiment or an original attainability principle. It is
compatible with the known equal-overlap and fixed-inconclusive constructions.

## 4. The optical source-class corollary still requires a separate step

For the declared passive maps, one coherent input alpha has energy N=||alpha||^2.
Its output root overlaps are exp(-||(A_j-A_k)alpha||^2/2). Define

$$
H_\Delta=\frac{1}{m(m-1)}\sum_{j<k}(A_j-A_k)^\dagger(A_j-A_k),
\qquad \kappa=\|H_\Delta\|.
$$

Jensen's inequality and the spectral bound give

$$
R_\alpha\ge e^{-\alpha^\dagger H_\Delta\alpha}\ge e^{-\kappa N}.
$$

Together with the previous section and C+E+F=1,

$$
\left(\sqrt C-\sqrt{E/(m-1)}\right)^2\le 1-e^{-\kappa N}.
$$

An especially short way to cover mixtures is to retain their label z. Apply the
per-pulse statement before averaging. If N_z has finite mean at most mu, then

$$
e^{-\kappa\mu}\le\mathbb E_z e^{-\kappa N_z}
\le\mathbb E_z R_z
\le F+\frac{2}{\sqrt{m-1}}\mathbb E_z\sqrt{C_zE_z}
+\frac{m-2}{m-1}E
\le F+2\sqrt{CE/(m-1)}+\frac{m-2}{m-1}E.
$$

The first inequality uses monotonicity and Jensen; the last is Cauchy-Schwarz.
This is equivalent to the canonical joint-concavity proof. It remains valid for
unbounded pulse-energy distributions with finite mean; a finite energy scan is
not the proof. Each component may use its own measurement, as the receiver knows
z. A reference state independent of the hidden hypothesis conditional on z does
not alter that component's distinguishability. Output loss modes remain
inaccessible and the maps retain their common physical optical phase reference.

The resulting upper branch, also capped by C+E<=1, is the repository formula

$$
C\le\min\left\{1-E,
\left[\sqrt{1-e^{-\kappa\mu}}+\sqrt{E/(m-1)}\right]^2\right\}.
$$

**Interpretation:** the all-transmitter and all-intensity guarantee is not lost.
It follows here as an explicit optical corollary of credited ingredients. The
complete contract was not located verbatim in a predecessor, but that absence
is not a strong independent novelty argument once this short derivation is known.
At zero error it already follows from S20 and the same overlap/Jensen step.
At F=0 the main state-level ingredient is exactly S22. At uniform four-symbol
loss, the fixed-alphabet attainment remains the Herzog specialization identified
in audit 01. No arbitrary-map tightness is inferred.

## 5. Why S18 does not directly give either of the project optima

S18's formal target is a two-hypothesis channel problem. Its Appendix F includes
a finite-n statement, so it would be inaccurate to exclude it merely as an
asymptotic paper. That statement is

$$
-\frac1n\log\beta_n^*(E,\varepsilon)
\le\frac{\widehat D_{H,E}(\mathcal N\|\mathcal M)
+h_2(\varepsilon)/n}{1-\varepsilon}.
$$

Its objective, admissible signal-reference inputs, and adaptive repeated-call
model differ from our restricted single-photon C-lambda E problem and from the
classical source-class problem. Appendix H still optimizes channel divergences;
it does not secretly change to m-label correct/error/failure optimization.
This observation is a comparison of theorem contracts, not an independent audit
of all of S18's SDP implementations.

There is also a direct witness that plugging our coherent states into its
relative-entropy ceiling is not the desired certificate. Let two normalized
pure outputs have root overlap 0<c<1. Their one-dimensional supports differ:

$$
\mathrm{Tr}[\rho(I-\sigma)]=1-c^2>0.
$$

By the support condition in S18 Eq. (4), D(rho||sigma)=infinity; its BS upper
quantity is also infinite. This occurs for any two distinct pure coherent
outputs, at a finite nonzero illumination. The channel supremum includes such
an input, so the resulting divergence ceiling is vacuous for that pair. Our
overlap bound remains finite. This is not a claim that S18's results are useless
for noisy channels with mixed outputs or other objectives.

A finite two-dimensional representation makes the distinction explicit:

$$
|\phi\rangle=c|0\rangle+\sqrt{1-c^2}|1\rangle,\qquad
\sigma=|0\rangle\langle0|.
$$

For sigma_eps=(1-eps)sigma+eps I/2,

$$
D(|\phi\rangle\langle\phi|\|\sigma_\epsilon)
=-c^2\log(1-\epsilon/2)-(1-c^2)\log(\epsilon/2),
$$

which diverges as eps approaches zero while the overlap stays c. At c=exp(-.7),
the mass outside the other support is 0.7534030361, and the four-symbol zero-error
classical conclusive rate from the optical comparison is 0.5034146962.
These are different operational questions, not contradictory limits.

## 6. What has and has not been shown

The exact old-notation substitutions, the failure-row completion, and the
source-mixture corollary are analytic derivations. Finite diagnostics test their
normalizations and explicit constructions, including unequal-prior algebra,
nonprojective POVMs, singular cases, and rare flashes. No test establishes
worldwide priority or the absence of another equivalent theorem.

Candidate A's full input-only optimum is not subsumed by the inspected S18/S20/S22
statements. That is not a claim that A's priority is cleared. Candidate B remains
a mathematically useful certificate, with stronger predecessor attribution and
less justification for presenting its state-level bound as a separate new result.
