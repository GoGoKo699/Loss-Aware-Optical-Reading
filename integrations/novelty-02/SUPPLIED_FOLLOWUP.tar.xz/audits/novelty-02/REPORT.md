# Predecessor follow-up 02: decision

**The two named source gaps have been addressed at the theorem-comparison level.
A closer predecessor was also found: the no-inconclusive part of our multiclass
measurement inequality is exactly a known wave-particle duality relation. Its
proof gives the full inequality after a straightforward failure-outcome
completion. The optical certificate remains valid; its independent novelty
weight should be reduced.**

Pinned repository baseline: `db17e1ec1868107b0fe1042d5a480769b552633e`.
No repository branch or commit was created. The current GitHub connection is
read-only, and direct Git access failed. This additions-only audit packet is
prepared for later import under `audits/novelty-02/`. Main and all earlier
scientific material are unchanged.

## 1. What is resolved

| Item | Previous gap | Finding in this follow-up |
|---|---|---|
| S18, Huang et al., arXiv:2603.19911v1 | Only abstract-level screening | Full text and the relevant appendices inspected. Its actual bounds do not directly give our two optima. Importantly, Appendix F also contains a finite-n bound, not only an asymptotic limit. |
| S20, Zhang et al., PRA 64, 062103 | Original full text unavailable; formula known indirectly | Full author-uploaded article text recovered and read. Its Theorem 1 is the exact zero-error overlap predecessor. Publisher PDF/visual retrieval remains unavailable, not the substantive theorem text. |
| Close-equivalent multiclass relation | No exact intermediate inequality identified | S22, Bagan et al., PRL 120, 050402, gives the exact F=0 relation. The failure-row extension recovers the project's whole measurement bound. |

The decisive source locators and actual formats are in [SOURCES.md](SOURCES.md).
The algebraic comparisons are in [REDUCTIONS.md](REDUCTIONS.md). No claim of an
exhaustive worldwide priority search follows from resolving these named items.

## 2. The important change is the status of the measurement inequality

The project uses R, the average root overlap of m equally likely returned states,
and unconditional correct/error/inconclusive probabilities C,E,F. Its statistical
step is

$$
R\le F+2\sqrt{CE/(m-1)}+\frac{m-2}{m-1}E.
$$

At F=0 this is S22's Lemma 1 after translating its normalization X=(m-1)R/m and
P_d=C. At E=0 it reduces to the S20 upper bound C<=1-R.

For F>0, separate any measurement's likelihood-amplitude matrix into its m
conclusive rows and one failure row. The conclusive block obeys the matrix
estimate in S22's proof. The failure row adds at most (m-1)F before normalization.
That gives the exact displayed relation. The completion is explained explicitly
rather than silently replacing an optimal-measurement theorem with a statement
about arbitrary measurements.

**Recommended classification:** the measurement inequality is a credited,
straightforward extension of known discrimination algebra, not an independent
new multiclass theorem. This is more specific than the previous observation
that its ingredients resembled older fidelity arguments.

The printed S22 lemma is not claimed to contain our F>0 optical formula verbatim.
The audit supplies the short missing reduction. It works for arbitrary final
measurements, including nonprojective ones and unequal per-label failure rates.
A numerical example with C=.5, E=.03, F=.47 has R=.6314213562373095 and an explicit
positive Gram construction attaining equality.

## 3. What remains of the all-classical-source result

The optical step is still necessary. A fixed-state measurement theorem alone
does not allow replacing the source, adding a phase reference, or using bright
flashes for free. In our passive-map model, coherent overlaps supply

$$
R_\alpha\ge e^{-\alpha^\dagger H_\Delta\alpha}
\ge e^{-\kappa\|\alpha\|^2}.
$$

Combine this with the credited measurement relation, then average over the
receiver-known illumination labels. Jensen controls the energy and
Cauchy-Schwarz controls the correct/error cross term. This recovers

$$
C\le\min\left\{1-E,
\left[\sqrt{1-e^{-\kappa\mu}}+\sqrt{E/(m-1)}\right]^2\right\}.
$$

The proof covers arbitrary finite-mean intensity distributions without a
bright-pulse cutoff. The broad comparator remains intact. The same argument at
E=0 is already an optical corollary of S20.

This is useful and operationally stronger than benchmarking one laser receiver.
However, after the exact predecessor reduction, **a conservative publication
position is to present B as a task-specific optical corollary and certification
tool**, with any novelty claimed for its precise operational formulation or
further genuinely distinct results, not for a new general state-discrimination
inequality. The whole optical statement was not found verbatim in an inspected
paper. That fact alone is not compelling novelty evidence.

No code, numerical value, confidence assumption, or first-experiment threshold
changes as a result of this classification. The uniform coherent alphabet's
attainment is still the known Herzog specialization from audit 01. The general
map ceiling remains a bound, not an exact optimum for every map.

## 4. The recent bosonic paper is relevant but not a direct subsumption

S18 studies binary channel discrimination, with signal-reference inputs and
adaptive repeated calls allowed in its upper bounds. Its finite-n Appendix F
statement controls type-II error under a type-I constraint using an
energy-constrained BS divergence. Appendix H gives divergence SDPs, not a hidden
m-label C/E/F optimization. These are meaningful differences in objective and
access, not merely differences in notation.

A concrete comparison prevents over-reliance on an abstract framework argument.
Two distinct pure coherent outputs have non-nested rank-one supports, even at
finite nonzero signal energy. Their Umegaki relative entropy is infinite by
S18's Eq. (4), so its BS-divergence ceiling is also infinite on such a pair. Our
root-overlap bound stays finite. This does not diminish the paper's results for
noisy channels with mixed outputs; it shows that its displayed divergence
ceiling does not produce this optical certificate by a direct substitution.

Two interpretive errors should also be avoided. Its Fock-diagonal reduced input
can be purified with a reference; that does not say that an incoherent signal
mixture alone resolves phase patterns. Its specified coherent comparison uses
heterodyne detection; it is not our optimum over every classical source and
receiver. The dephasing truncation theorem cannot be imported as a general
loss-dephasing cutoff certificate.

The task-relevant full-text comparison is complete for the inspected v1. We did
not rerun the external SDPs, re-prove the paper, or infer numerical conclusions
from its figures.

## 5. Consequences for the two candidate contributions and the experiment

**A remains the leading candidate mechanism result.** None of the named sources
or the newly identified relation supplies the entire joint input-only retuning
statement under its exact flat-code, diagonal-loss, and erasure contract. A's
priority is still not certified by that observation. Its known fixed-state
receiver and zero-error endpoint remain credited as before.

**B remains the necessary strong benchmark, with more conservative attribution.**
The all-source quantifiers cannot be weakened, but the measurement lemma should
not be advertised as new. Publication significance must come from the joint
design result, a genuinely useful operational certificate, or another separately
proved contribution, not from accumulating names for standard ingredients.

The first experiment need not be redesigned. M1 tests the predicted pre-device
retuning while keeping the decoder fixed. P1 still seeks an unconditional score
above the all-classical-source bound. P2 still requires an implemented coherent
receiver above the entire restricted photon bound. A known theoretical tool can
support a new experiment; its prior existence is not a reason to replace it with
a weaker benchmark.

The interpretation is not that an experiment proves the universal optimum.
Global optimality comes from the analytic theorem. Measurements test agreement
with its predictions in a calibrated physical realization. All source, phase,
loss, and trial-accounting assumptions remain requirements for the laboratory.

## 6. Executed checks

The independent script imports no canonical numerical module or external article
code. It ran 717 assertions across seven groups: endpoint normalizations, integer
counting, 80 actual random quantum POVMs, explicit failure-flag saturation,
coherent-map overlap bounds, finite intensity-mixture examples including bright
flashes, and the relative-entropy support distinction.

All passed at the predeclared default tolerance 2e-10; integer counts were exact.
The maximum violation or equality residual was 6.702971511174383e-15. A second
fresh-directory run reproduced RESULTS.json byte for byte. No frozen output
was overwritten. The source archive hashes and matched proof blob are recorded.

These are consistency checks on the displayed reductions, not tests of every
measurement or distribution, novelty proofs, interval certificates, external
peer review, or acquired laboratory data. The earlier 5,261/998/993 suites and
GitHub CI were not rerun in this read-only session and are not reported as fresh
verification.

## 7. Remaining limits and completion decision

The two named gaps are resolved at the level required for this comparison. The
S20 publisher PDF is still technically inaccessible; its original author-uploaded
text is now available. A further related 2022 paper by Xin Lu (S23) was available
only through publisher excerpts. It is recorded as an unadjudicated lead, not
used to claim an absent theorem or an additional exact equivalence.

No finite search can guarantee priority against every publication or unpublished
result. More importantly, this audit already supplies a concrete reduction that
changes the contribution assessment; it is not merely a request for more searches.

**Completion decision:** retain the mathematics and apparatus. Credit S20 and
S22 explicitly; treat the state-level part of B as inherited/straightforwardly
extended and its all-source optical form as a derived benchmark. Continue to
assess A on its exact joint-design statement. Suggested documentation wording is
provided in [PROPOSED_CLAIM_UPDATE.md](PROPOSED_CLAIM_UPDATE.md), not applied to the
canonical ledger.

This bounded task stops with the completed local packet. No remote commit,
merge, lab contact, or broader scientific extension has been performed.
