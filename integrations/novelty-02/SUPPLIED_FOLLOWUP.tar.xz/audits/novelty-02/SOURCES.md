# Sources, versions, and actual access

S18 and S20 retain audit 01's numbering. S22 and S23 are additional records.
Equations below refer to the linked PDF unless stated otherwise. The audit uses
primary articles, including an author-uploaded copy; it does not treat indexing
snippets as theorem evidence. No external article is redistributed.

## S18. Huang, Lami, Singh, and Wilde

*Efficiently Computable Strategies and Limits for Bosonic Channel Discrimination*,
arXiv:2603.19911v1, 20 March 2026.

- [Record](https://arxiv.org/abs/2603.19911)
- [Full HTML](https://arxiv.org/html/2603.19911v1)
- [Full PDF](https://arxiv.org/pdf/2603.19911v1)

**Access:** full HTML and 29-page PDF text obtained. Scope-defining main text and
Appendices A, B, F, G, H, and J inspected; C/D/E's operator/SDP methods and I's
scope catalogued. No numerical figure values or ancillary code were used.

**Locators:** PDF Eqs. (1)-(4), (8), (15)-(16); Appendix B Lemmas 1-2; Appendix F
Proposition 1, Eq. (F1); Appendix H.1-H.4; Appendix J Proposition 2, Eq. (J1).
Sec. III.B explicitly describes the reduced Fock-diagonal state and its
purification, and specifies a coherent-plus-heterodyne control. The appendix
truncation guarantee is for dephasing. This is a contract comparison, not a
verification of every result in the paper.

**Numbering caution:** the HTML globally renumbers displays. PDF (15), (F1),
and (J1) correspond to HTML (22), (144), and (238). Use the PDF locators above.
The record currently lists v1; no later version was inferred.

## S20. Zhang, Feng, Sun, and Ying

*Upper bound for the success probability of unambiguous discrimination among
quantum states*, Physical Review A **64**, 062103 (2001), published 8 November.

- [Publisher record](https://journals.aps.org/pra/abstract/10.1103/PhysRevA.64.062103)
- [Author-uploaded full text](https://www.researchgate.net/publication/243451242_Upper_bound_for_the_success_probability_of_unambiguous_discrimination_among_quantum_states)
- [Author group record](https://quantum.cs.tsinghua.edu.cn/publication/phys-rev-a-64-062103/)

**Access:** the author-content page identifies Yuan Feng's upload of 18 March
2014 and exposes the full three-page article text. The introduction, Definition 1,
Theorem 1 and its proof, conclusion, and successive-measurement discussion were
read. This is no longer merely an indirect quotation through Montanaro.

**Locators:** pp. 062103-1 to 062103-3; Definition 1 and Theorem 1, particularly
the ordered pair sum with prefactor 1/(n-1). PDF download/screenshot access was
not recovered, and some mathematical glyphs in the text extraction are damaged.
The theorem's normalization was independently reconstructed and agrees with the
previous primary-paper quotation. Only the upper bound is imported, not generic
tightness or new-copy/query claims.

## S22. Bagan, Calsamiglia, Bergou, and Hillery

*Duality games and operational duality relations*, arXiv:1708.03968v1, 13 August
2017; Physical Review Letters **120**, 050402 (2018).

- [Record](https://arxiv.org/abs/1708.03968)
- [Full PDF](https://arxiv.org/pdf/1708.03968)
- [DOI](https://doi.org/10.1103/PhysRevLett.120.050402)

**Access:** full eight-page PDF text; Eq. (5), Lemma 1/Eq. (9), Eq. (12), and
supplemental proof Eqs. (18)-(36), including the weighted Gram representation and
off-diagonal counting, inspected. This gives an exact F=0 match. Our failure-row
completion is explicitly distinguished from the printed optimal-measurement
statement. The record lists v1; its unversioned PDF endpoint worked, while
version-suffixed endpoints and screenshots failed. Figures are not used.

## S23. Xin Lu (Xin Lü)

*An upper bound on the success probability of minimum-error discrimination*,
Physics Letters A **452**, 128461 (2022).

- [Publisher page](https://www.sciencedirect.com/science/article/pii/S0375960122005436)
- [DOI](https://doi.org/10.1016/j.physleta.2022.128461)

**Access:** publisher abstract, introduction, and section excerpts only. The
complete Eq. (17) and its proof were not recovered. This is a relevant coherence/
minimum-error lead, not evidence for an exact formula or a claim that it does not
subsume a result. The decisive reduction here uses the available S22 proof and
does not depend on guessing S23's equation.

## Previously inspected sources used as context

The exact Herzog positive-overlap substitution, Bouchet binary-contrast factor,
and prior Gram/POVM framework remain as recorded in
[audit 01](../novelty-01/SOURCES.md), S07, S11, S10 and S14. This task does not
relabel those sources or count their old inspection as a new full-text audit.

## Technical access limitations

Public PDF text was readable through the web tool. PDF screenshots returned
internal errors; no diagram, graph, or table inference was used. Container DNS
prevented direct article downloads and authenticated Git access. ResearchGate
PDF links failed, but its author-uploaded full article text was readable.
No paywall was bypassed. No message requesting papers was sent to an author.
