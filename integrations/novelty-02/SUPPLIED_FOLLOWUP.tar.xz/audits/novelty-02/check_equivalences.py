"""Independent checks for the predecessor reductions in novelty follow-up 02.

This checks equations and examples, not originality, all measurements, or all
intensity distributions. The analytic arguments are in REDUCTIONS.md. No source
from the canonical implementation or an external article is imported.

Usage from a repository checkout:
  python audits/novelty-02/check_equivalences.py --output results/runs/novelty-02
The output directory must be new. NumPy is the only non-standard dependency.
"""
from __future__ import annotations
import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import platform
import sys
import time
import numpy as np

SEED = 2026091502
BASELINE = 'db17e1ec1868107b0fe1042d5a480769b552633e'
TOL = 2e-10


def psd_sqrt(a: np.ndarray) -> np.ndarray:
    values, vectors = np.linalg.eigh((a + a.conj().T) / 2)
    if values.min() < -1e-10:
        raise ArithmeticError('Matrix is not positive semidefinite')
    return (vectors * np.sqrt(np.maximum(values, 0))) @ vectors.conj().T


def random_povm(rng: np.random.Generator, d: int, outcomes: int) -> np.ndarray:
    g = rng.normal(size=(outcomes, d, d)) + 1j*rng.normal(size=(outcomes, d, d))
    a = g.conj().transpose(0, 2, 1) @ g
    values, vectors = np.linalg.eigh(a.sum(axis=0))
    inv = (vectors / np.sqrt(values)) @ vectors.conj().T
    return inv @ a @ inv


def mean_root_overlap(gram: np.ndarray) -> float:
    m = len(gram)
    return float((np.abs(gram).sum()-np.abs(np.diag(gram)).sum())/(m*(m-1)))


def h_contrast(maps: np.ndarray) -> tuple[np.ndarray, float]:
    m, _, d = maps.shape
    h = np.zeros((d, d), complex)
    for j in range(m):
        for k in range(j):
            delta = maps[j]-maps[k]
            h += delta.conj().T @ delta
    h /= m*(m-1)
    return h, float(np.linalg.eigvalsh(h)[-1])


def coherent_gram(outputs: np.ndarray) -> np.ndarray:
    norm = np.sum(np.abs(outputs)**2, axis=1)
    return np.exp(outputs.conj()@outputs.T - (norm[:, None]+norm[None, :])/2)


def classical_ceiling(kappa: float, mu: float, e: float, m: int) -> float:
    a = -math.expm1(-kappa*mu)
    return min(1-e, (math.sqrt(a)+math.sqrt(max(e, 0)/(m-1)))**2)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    output = args.output.resolve()
    # In a later checkout, never create fresh calculations in frozen results/.
    root = Path(__file__).resolve().parents[2]
    frozen = root/'results'
    runs = frozen/'runs'
    if output.exists() or output == frozen or output == runs:
        parser.error('Output must be a new directory')
    if frozen in output.parents and runs not in output.parents:
        parser.error('New repository results must be below results/runs/')
    t0 = time.perf_counter()
    rng = np.random.default_rng(SEED)
    checks = []
    examples = {}
    cases = Counter()

    def equal(group: str, name: str, actual: float, expected: float, tol: float=TOL) -> None:
        residual = abs(float(actual)-float(expected))
        add(group, name, residual, tol)

    def le(group: str, name: str, left: float, right: float, tol: float=TOL) -> None:
        slack = float(right-left)
        add(group, name, max(0., -slack), tol, slack)

    def add(group: str, name: str, residual: float, tol: float, slack=None) -> None:
        if not math.isfinite(residual) or (slack is not None and not math.isfinite(slack)):
            raise AssertionError((group, name, 'nonfinite comparison'))
        record = {'group':group, 'name':name, 'residual':residual, 'tolerance':tol}
        if slack is not None:
            record['slack'] = slack
        checks.append(record)
        if residual > tol:
            raise AssertionError(record)

    # A. Known zero-error S20 limit and Bagan-2018 F=0 relation.
    # Symmetric positive-overlap ensembles saturate both endpoints.
    for m in (2, 3, 4, 5, 8):
        for c in (0., .05, .3, .7, .95, 1.):
            name = f'm{m}_overlap{c}'
            cme = (math.sqrt(1+(m-1)*c)+(m-1)*math.sqrt(1-c))**2/m**2
            e = max(0., 1-cme)
            bagan_x = ((m-2)*e+2*math.sqrt((m-1)*cme*e))/m
            our_r = (m-2)*e/(m-1)+2*math.sqrt(cme*e/(m-1))
            equal('endpoint_translation', name+'_X_normalization', bagan_x, (m-1)*our_r/m)
            equal('endpoint_translation', name+'_ME_saturation', our_r, c)
            # S20 ordered-pair sum for uniform priors is m-1 times R.
            s20 = 1-(m*(m-1)*(c/m))/(m-1)
            equal('endpoint_translation', name+'_S20', s20, 1-c)
            cases['symmetric_endpoint_ensembles'] += 1

    # B. Counting coefficient in the published proof, exact integer arithmetic.
    for m in range(2, 10):
        count = np.zeros((m, m), int)
        for i in range(m):
            for j in range(m):
                if i == j:
                    continue
                for k in range(m):
                    if k != i and k != j:
                        count[k, i] += 1
        target = (m-2)*(np.ones((m, m), int)-np.eye(m, dtype=int))
        equal('counting', f'm{m}_multiplicity', np.abs(count-target).max(), 0, tol=0)
        cases['integer_multiplicity_cases'] += 1

    # C. The failure-row completion for actual arbitrary quantum POVMs.
    # Half the cases have unequal priors, solely to check the weighted algebra.
    # No unequal-prior optical theorem is claimed from these tests.
    for m in (2, 3, 4, 8):
        for d in (2, m):
            for rep in range(10):
                name = f'm{m}_d{d}_case{rep}'
                psi = rng.normal(size=(d, m))+1j*rng.normal(size=(d, m))
                psi /= np.linalg.norm(psi, axis=0)
                prior = np.full(m, 1/m) if rep % 2 == 0 else rng.dirichlet(np.ones(m))
                povm = random_povm(rng, d, m+1)
                p = np.real(np.einsum('di,ydk,ki->yi', psi.conj(), povm, psi))
                equal('flagged_POVM', name+'_normalization', np.max(abs(p.sum(axis=0)-1)), 0)
                p = np.maximum(0., p)
                weights = p*prior[None, :]
                bc, bf = np.sqrt(weights[:m]), np.sqrt(weights[m:])
                c = float(np.trace(weights[:m]))
                e = float(weights[:m].sum()-c)
                f = float(weights[m:].sum())
                g = psi.conj().T@psi
                w = np.sqrt(prior[:, None]*prior[None, :])*np.abs(g)
                overlap = float(w.sum()-np.trace(w))
                wc = bc.T@bc
                wf = bf.T@bf
                oc = float(wc.sum()-np.trace(wc))
                of = float(wf.sum()-np.trace(wf))
                rhs = (m-2)*e+2*math.sqrt((m-1)*c*e)+(m-1)*f
                le('flagged_POVM', name+'_data_processing', overlap, oc+of)
                le('flagged_POVM', name+'_conclusive_Bagan_algebra', oc,
                   (m-2)*e+2*math.sqrt((m-1)*c*e))
                le('flagged_POVM', name+'_failure_row', of, (m-1)*f)
                le('flagged_POVM', name+'_weighted_complete_bound', overlap, rhs)
                if rep % 2 == 0:
                    r = mean_root_overlap(g)
                    equal('flagged_POVM', name+'_uniform_scaling', overlap, (m-1)*r)
                    le('flagged_POVM', name+'_square_form',
                       (math.sqrt(c)-math.sqrt(e/(m-1)))**2, 1-r)
                cases['random_quantum_POVMs'] += 1

    # D. Explicit pure-state constructions attain the extended measurement bound.
    # Columns sqrt(m)*B are normalized states; measuring rows gives C,E,F.
    for m in (2, 3, 4, 8):
        for c, e, f in ((.5,.03,.47), (.15,.7,.15), (.2,0.,.8), (0.,.6,.4)):
            name = f'm{m}_C{c}_E{e}'
            b = np.full((m+1, m), math.sqrt(e/(m*(m-1))))
            np.fill_diagonal(b[:m], math.sqrt(c/m))
            b[m, :] = math.sqrt(f/m)
            psi = math.sqrt(m)*b
            g = psi.T@psi
            r = mean_root_overlap(g)
            expected = f+2*math.sqrt(c*e/(m-1))+(m-2)*e/(m-1)
            equal('attainment', name+'_normalized_states', np.max(abs(np.diag(g)-1)), 0)
            equal('attainment', name+'_R', r, expected)
            equal('attainment', name+'_square', (math.sqrt(c)-math.sqrt(e/(m-1)))**2, 1-r)
            if m == 4 and c == .5:
                examples['flagged_saturation'] = {'m':m,'C':c,'E':e,'F':f,'R':r,
                    'gram_eigenvalues':np.linalg.eigvalsh(g).tolist()}
            cases['explicit_flagged_ensembles'] += 1

    # E. Optical map step and mixtures. Gram representation avoids Fock truncation.
    for m in (3, 4, 6):
        d = 4
        maps = rng.normal(size=(m,d,d))+1j*rng.normal(size=(m,d,d))
        for j in range(m):
            maps[j] *= rng.uniform(.3,.9)/np.linalg.norm(maps[j],2)
        h, kappa = h_contrast(maps)
        for n in (0., .02, .7, 3., 20.):
            a = rng.normal(size=d)+1j*rng.normal(size=d)
            a *= math.sqrt(n)/np.linalg.norm(a)
            out = np.einsum('jik,k->ji', maps, a)
            g = coherent_gram(out)
            r = mean_root_overlap(g)
            quadratic = float(np.real(a.conj()@h@a))
            le('optical_step', f'm{m}_N{n}_Jensen', math.exp(-quadratic), r)
            le('optical_step', f'm{m}_N{n}_spectral', quadratic, kappa*n)
            # A physical receiver on the span of the coherent alphabet.
            rootg = np.ones((m,m))/math.sqrt(m) if n == 0 else psd_sqrt(g)
            scale = .73
            c = scale*float(np.mean(abs(np.diag(rootg))**2))
            e = scale*float((np.abs(rootg)**2).sum()/m)-c
            le('optical_step', f'm{m}_N{n}_score', c, classical_ceiling(kappa,n,e,m))
            cases['coherent_map_cases'] += 1

    # Rare-flash examples test implementation/normalization, not infinite support.
    m = 4
    t = .7
    flash_examples = []
    for probability in (1., .5, .1, .001, 1e-9):
        energy = 1/probability
        overlap = math.exp(-t*energy)
        bright_correct = (math.sqrt(1+3*overlap)+3*math.sqrt(1-overlap))**2/16
        # The mixture label is available: discard vacuum pulses, use the bright receiver.
        c = probability*bright_correct
        e = probability*(1-bright_correct)
        bound = classical_ceiling(t,1.,e,m)
        le('mean_mixtures', f'flash_probability_{probability}', c, bound)
        flash_examples.append({'bright_probability':probability,'bright_photons':energy,
                               'mean_photons':1.,'C':c,'E':e,'classical_upper':bound})
        cases['rare_flash_mixtures'] += 1
    for rep in range(20):
        energies = rng.lognormal(mean=-.5, sigma=2., size=6)
        weights = rng.dirichlet(np.ones(6))
        scales = rng.uniform(.1,1.,6)
        overlaps = np.exp(-t*energies)
        me = (np.sqrt(1+3*overlaps)+3*np.sqrt(1-overlaps))**2/16
        c = float(weights@(scales*me))
        e = float(weights@(scales*(1-me)))
        mu = float(weights@energies)
        le('mean_mixtures', f'random_mixture_{rep}', c, classical_ceiling(t,mu,e,m))
        cases['random_intensity_mixtures'] += 1
    examples['rare_flash_mixtures'] = flash_examples

    # F. S18's divergence ceiling and our finite single-shot setting are different.
    # Distinct pure outputs have non-nested rank-one supports even when nonorthogonal.
    values = []
    for overlap in (.2, math.exp(-.7), .8):
        psi = np.array([overlap, math.sqrt(1-overlap**2)])
        rho = np.outer(psi, psi)
        sigma = np.diag([1.,0.])
        mass = float(np.trace(rho@(np.eye(2)-sigma)))
        equal('divergence_scope', f'overlap_{overlap}_support_mass', mass, 1-overlap**2)
        le('divergence_scope', f'overlap_{overlap}_distinct_support', 1e-3, mass)
        regularized = []
        for eps in (1e-2,1e-5,1e-8,1e-11):
            logs = np.diag(np.log([1-eps/2,eps/2]))
            direct = -float(np.trace(rho@logs))  # Tr rho log rho = 0 for pure rho.
            expression = -overlap**2*math.log1p(-eps/2)-mass*math.log(eps/2)
            equal('divergence_scope', f'overlap_{overlap}_eps_{eps}', direct, expression)
            regularized.append(direct)
        le('divergence_scope', f'overlap_{overlap}_regularization_trend',
           1., min(np.diff(regularized)))
        values.append({'root_overlap':overlap,'mass_outside_other_support':mass,
                       'regularized_Umegaki_values':regularized,
                       'unregularized_relative_entropy':'infinite_by_support_condition'})
        cases['pure_output_support_witnesses'] += 1
    examples['S18_scope_witness'] = values
    examples['four_symbol_uniform_check'] = {
        'transmission':t,'mean_signal_photons':1.,'root_overlap':math.exp(-t),
        'zero_error_classical_C':-math.expm1(-t),
        'minimum_error_classical_C':(math.sqrt(1+3*math.exp(-t))+3*math.sqrt(1-math.exp(-t)))**2/16}

    result = {
        'status':'PASS','baseline_commit':BASELINE,'seed':SEED,
        'assertions':len(checks),'case_counts':dict(cases),
        'groups':dict(Counter(c['group'] for c in checks)),
        'max_violation_or_identity_residual':max(c['residual'] for c in checks),
        'default_tolerance':TOL,'interval_arithmetic':False,
        'independent_of_canonical_code':True,'lab_data':False,
        'scope':'Finite equation and construction checks. Universal relations are derived in REDUCTIONS.md; no search or numerical test proves priority.',
        'checks':checks,'examples':examples}
    output.mkdir(parents=True, exist_ok=False)
    (output/'RESULTS.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    environment = {'python':sys.version,'numpy':np.__version__,'platform':platform.platform(),
                   'utc':datetime.now(timezone.utc).isoformat(),
                   'runtime_seconds':time.perf_counter()-t0,
                   'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                   'network_used_by_script':False,'external_article_code_imported':False,
                   'repository_write_performed':False}
    (output/'ENVIRONMENT.json').write_text(json.dumps(environment,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ('status','assertions','case_counts','groups',
                                          'max_violation_or_identity_residual','examples')},indent=2))

if __name__ == '__main__':
    main()
