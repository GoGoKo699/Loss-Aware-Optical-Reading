"""Verify this additions-only packet's recorded bytes; no repository/network access."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path


def main() -> None:
    root = Path(__file__).resolve().parent
    manifest = json.loads((root / 'MANIFEST.json').read_text(encoding='utf-8'))
    if manifest.get('schema') != 1:
        raise ValueError('Unsupported manifest schema')
    for relative, expected in manifest['files'].items():
        path = (root / relative).resolve()
        if root not in path.parents or not path.is_file() or path.is_symlink():
            raise ValueError('Invalid packet path: ' + relative)
        actual = hashlib.sha256(path.read_bytes()).hexdigest()
        if actual != expected:
            raise ValueError('Packet hash mismatch: ' + relative)
    print(json.dumps({'status': 'PASS', 'files': len(manifest['files']),
                      'baseline': manifest['baseline_commit'],
                      'scope': 'File integrity only; no CI, priority or experimental certificate.'}, indent=2))


if __name__ == '__main__':
    main()
